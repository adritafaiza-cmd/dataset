// =============================================================================
// Copyright (C) 2018-2022 Xilinx, Inc. All rights reserved.
// SPDX-License-Identifier: MIT
// =============================================================================

`timescale 1ns / 1ps

`include "axi_register.vh"

`ifdef AXI_REGISTER_SYNTHESIS
`else
`endif

module axis_register #(
    parameter DATA_WIDTH = 8,
    parameter KEEP_ENABLE = (DATA_WIDTH>8),
    parameter KEEP_WIDTH = ((DATA_WIDTH+7)/8),
    parameter LAST_ENABLE = 1,
    parameter ID_ENABLE = 0,
    parameter ID_WIDTH = 8,
    parameter DEST_ENABLE = 0,
    parameter DEST_WIDTH = 8,
    parameter USER_ENABLE = 1,
    parameter USER_WIDTH = 1,
    parameter REG_TYPE = 2
) (
    input  wire                   clk,
    input  wire                   rst,

    /*
     * AXI Stream input
     */
    input  wire [DATA_WIDTH-1:0]  s_axis_tdata,
    input  wire [KEEP_WIDTH-1:0]  s_axis_tkeep,
    input  wire                   s_axis_tvalid,
    output wire                   s_axis_tready,
    input  wire                   s_axis_tlast,
    input  wire [ID_WIDTH-1:0]    s_axis_tid,
    input  wire [DEST_WIDTH-1:0]  s_axis_tdest,
    input  wire [USER_WIDTH-1:0]  s_axis_tuser,

    /*
     * AXI Stream output
     */
    output wire [DATA_WIDTH-1:0]  m_axis_tdata,
    output wire [KEEP_WIDTH-1:0]  m_axis_tkeep,
    output wire                   m_axis_tvalid,
    input  wire                   m_axis_tready,
    output wire                   m_axis_tlast,
    output wire [ID_WIDTH-1:0]    m_axis_tid,
    output wire [DEST_WIDTH-1:0]  m_axis_tdest,
    output wire [USER_WIDTH-1:0]  m_axis_tuser
);

    wire [DATA_WIDTH-1:0]  tdata;
    wire [KEEP_WIDTH-1:0]  tkeep;
    wire                   tvalid;
    wire                   tready;
    wire                   tlast;
    wire [ID_WIDTH-1:0]    tid;
    wire [DEST_WIDTH-1:0]  tdest;
    wire [USER_WIDTH-1:0]  tuser;

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    assign tdata = s_axis_tdata;
    assign tkeep = s_axis_tkeep;
    assign tvalid = s_axis_tvalid;
    assign tready = s_axis_tready;
    assign tlast = s_axis_tlast;
    assign tid = s_axis_tid;
    assign tdest = s_axis_tdest;
    assign tuser = s_axis_tuser;
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    assign m_axis_tdata = tdata;
    assign m_axis_tkeep = tkeep;
    assign m_axis_tvalid = tvalid;
    assign m_axis_tready = tready;
    assign m_axis_tlast = tlast;
    assign m_axis_tid = tid;
    assign m_axis_tdest = tdest;
    assign m_axis_tuser = tuser;
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS
    `else
    `endif

    `ifdef AXI_REGISTER_SYNTHESIS