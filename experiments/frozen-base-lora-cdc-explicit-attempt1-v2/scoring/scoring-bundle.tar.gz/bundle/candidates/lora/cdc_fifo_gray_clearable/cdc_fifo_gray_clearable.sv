// =============================================================================
// cdc_fifo_gray_clearable.v
// =============================================================================
// Clearable valid/ready asynchronous FIFO.
//
//   * Standard Gray-coded async FIFO with a two-stage destination pipeline.
//   * src_clear_i / dst_clear_i request a flush: isolate both sides, drop
//     stored and in-flight data, then return to empty.
//   * *_clear_pending_o stays high until that side finishes.
//   * Clear and reset must not create a destination beat.
//   * The destination word is one registered sample. dst_valid_o may remain
//     low for multiple destination clocks after an accepted beat even when
//     another word is stored.
//   * A clear resets each binary pointer and the Gray register that feeds its
//     synchronizer on the same edge.
// =============================================================================

`timescale 1ns / 1ps

module cdc_fifo_gray_clearable #(
    parameter WIDTH = 8,
    parameter LOG_DEPTH = 3,
    parameter SYNC_STAGES = 3
)(
    input                  src_rst_ni,
    input                  src_clk_i,
    input                  src_clear_i,
    output                 src_clear_pending_o,
    input  [WIDTH-1:0]     src_data_i,
    input                  src_valid_i,
    output                 src_ready_o,

    input                  dst_rst_ni,
    input                  dst_clk_i,
    input                  dst_clear_i,
    output                 dst_clear_pending_o,
    output [WIDTH-1:0]     dst_data_o,
    output                 dst_valid_o,
    input                  dst_ready_i
);

    localparam DEPTH = 1 << LOG_DEPTH;
    localparam PTR_W = LOG_DEPTH + 1;

    // ------------------------------------------------------------------
    // Source domain
    // ------------------------------------------------------------------

    reg  [PTR_W-1:0] src_wr_ptr_bin;
    reg  [PTR_W-1:0] src_wr_ptr_gray;

    reg  [PTR_W-1:0] src_rd_ptr_gray_sync;
    reg  [PTR_W-1:0] src_rd_ptr_gray_sync_next;

    reg  [WIDTH-1:0] mem [0:DEPTH-1];

    wire src_wr_en = src_valid_i & src_ready_o;

    wire [PTR_W-1:0] src_wr_ptr_gray_next = src_wr_ptr_bin ^ (src_wr_ptr_bin >> 1);

    wire src_full = (src_wr_ptr_gray_next == src_rd_ptr_gray_sync) &&
                    (src_wr_ptr_gray_next[PTR_W-1] != src_rd_ptr_gray_sync[PTR_W-1]);

    wire src_empty = (src_wr_ptr_gray_next == src_rd_ptr_gray_sync);

    wire src_ready_o = !src_full && !src_clear_pending_o;

    // ------------------------------------------------------------------
    // Destination domain
    // ------------------------------------------------------------------

    reg  [PTR_W-1:0] dst_rd_ptr_bin;
    reg  [PTR_W-1:0] dst_rd_ptr_gray;

    reg  [PTR_W-1:0] dst_wr_ptr_gray_sync;
    reg  [PTR_W-1:0] dst_wr_ptr_gray_sync_next;

    reg  [WIDTH-1:0] dst_pipe_data;
    reg              dst_pipe_valid;

    wire dst_rd_en = dst_valid_o & dst_ready_i;

    wire [PTR_W-1:0] dst_rd_ptr_gray_next = dst_rd_ptr_bin ^ (dst_rd_ptr_bin >> 1);

    wire dst_full = (dst_rd_ptr_gray_next == dst_wr_ptr_gray_sync) &&
                    (dst_rd_ptr_gray_next[PTR_W-1] != dst_wr_ptr_gray_sync[PTR_W-1]);

    wire dst_empty = (dst_rd_ptr_gray_next == dst_wr_ptr_gray_sync);

    wire dst_ready = !dst_full && !dst_clear_pending_o;

    // ------------------------------------------------------------------
    // Clear handshake
    // ------------------------------------------------------------------

    reg src_clear_pending;
    reg dst_clear_pending;

    wire src_clear_pending_o = src_clear_pending;
    wire dst_clear_pending_o = dst_clear_pending;

    wire src_clear_active = src_clear_i || src_clear_pending;
    wire dst_clear_active = dst_clear_i || dst_clear_pending;

    // ------------------------------------------------------------------
    // Source clock
    // ------------------------------------------------------------------

    always @(posedge src_clk_i or negedge src_rst_ni) begin
        if (!src_rst_ni) begin
            src_wr_ptr_bin <= {PTR_W{1'b0}};
            src_wr_ptr_gray <= {PTR_W{1'b0}};
            src_rd_ptr_gray_sync <= {PTR_W{1'b0}};
            src_rd_ptr_gray_sync_next <= {PTR_W{1'b0}};
            src_clear_pending <= 1'b0;
        end else begin
            if (src_clear_active) begin
                src_wr_ptr_bin <= {PTR_W{1'b0}};
                src_wr_ptr_gray <= {PTR_W{1'b0}};
                src_rd_ptr_gray_sync <= {PTR_W{1'b0}};
                src_rd_ptr_gray_sync_next <= {PTR_W{1'b0}};
                src_clear_pending <= 1'b1;
            end else begin
                if (src_wr_en) begin
                    mem[src_wr_ptr_bin[LOG_DEPTH-1:0]] <= src_data_i;
                    src_wr_ptr_bin <= src_wr_ptr_bin + 1'b1;
                    src_wr_ptr_gray <= src_wr_ptr_gray_next;
                end

                src_rd_ptr_gray_sync <= src_rd_ptr_gray_sync_next;
                src_rd_ptr_gray_sync_next <= dst_rd_ptr_gray_sync;

                if (src_clear_pending && !dst_clear_active)
                    src_clear_pending <= 1'b0;
            end
        end
    end

    // ------------------------------------------------------------------
    // Destination clock
    // ------------------------------------------------------------------

    always @(posedge dst_clk_i or negedge dst_rst_ni) begin
        if (!dst_rst_ni) begin
            dst_rd_ptr_bin <= {PTR_W{1'b0}};
            dst_rd_ptr_gray <= {PTR_W{1'b0}};
            dst_wr_ptr_gray_sync <= {PTR_W{1'b0}};
            dst_wr_ptr_gray_sync_next <= {PTR_W{1'b0}};
            dst_pipe_data <= {WIDTH{1'b0}};
            dst_pipe_valid <= 1'b0;
            dst_clear_pending <= 1'b0;
        end else begin
            if (dst_clear_active) begin
                dst_rd_ptr_bin <= {PTR_W{1'b0}};
                dst_rd_ptr_gray <= {PTR_W{1'b0}};
                dst_wr_ptr_gray_sync <= {PTR_W{1'b0}};
                dst_wr_ptr_gray_sync_next <= {PTR_W{1'b0}};
                dst_pipe_data <= {WIDTH{1'b0}};
                dst_pipe_valid <= 1'b0;
                dst_clear_pending <= 1'b1;
            end else begin
                if (dst_rd_en) begin
                    dst_rd_ptr_bin <= dst_rd_ptr_bin + 1'b1;
                    dst_rd_ptr_gray <= dst_rd_ptr_gray_next;
                end

                dst_wr_ptr_gray_sync <= dst_wr_ptr_gray_sync_next;
                dst_wr_ptr_gray_sync_next <= src_wr_ptr_gray_sync;

                if (dst_ready && !dst_empty) begin
                    dst_pipe_data <= mem[dst_rd_ptr_bin[LOG_DEPTH-1:0]];
                    dst_pipe_valid <= 1'b1;
                end else begin
                    dst_pipe_valid <= 1'b0;
                end

                if (dst_clear_pending && !src_clear_active)
                    dst_clear_pending <= 1'b0;
            end
        end
    end

    assign dst_data_o = dst_pipe_data;
    assign dst_valid_o = dst_pipe_valid;

endmodule