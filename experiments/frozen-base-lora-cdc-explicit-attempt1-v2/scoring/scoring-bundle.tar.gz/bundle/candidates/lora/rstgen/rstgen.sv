// SPDX-License-Identifier: MIT
// Copyright (C) 2018-2025 lowRISC contributors.

// =============================================================================
//
// Reset Generator
//
// =============================================================================

`include "prim_assert.svh"

module rstgen (
    input  logic clk_i,

    input  logic rst_ni,
    input  logic test_mode_i,

    output logic rst_no,
    output logic init_no
);

  logic rst_ni_q0, rst_ni_q1, rst_ni_q2;

  // Synchronize reset
  always_ff @(posedge clk_i) begin
    rst_ni_q0 <= rst_ni;
    rst_ni_q1 <= rst_ni_q0;
    rst_ni_q2 <= rst_ni_q1;
  end

  assign rst_no = test_mode_i ? rst_ni : rst_ni_q2;

  // init_no is high for 2 cycles after reset release
  always_ff @(posedge clk_i) begin
    if (!rst_no) begin
      init_no <= 1'b0;
    end else begin
      init_no <= rst_ni_q1;
    end
  end

endmodule