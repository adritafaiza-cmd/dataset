// SPDX-License-Identifier: MIT
// Copyright (C) 2018-2025 lowRISC contributors.

// Single-bit destination-clock synchronizer.
module sync #(
    parameter int unsigned STAGES = 2,
    parameter bit ResetValue = 1'b0
) (
    input  logic clk_i,
    input  logic rst_ni,

    input  logic serial_i,

    output logic serial_o
);

    (* ASYNC_REG = "TRUE" *) logic [STAGES-1:0] sync_ff;

    always_ff @(posedge clk_i, negedge rst_ni) begin
        if (!rst_ni) begin
            sync_ff <= {STAGES{ResetValue}};
        end else begin
            sync_ff <= {sync_ff[STAGES-2:0], serial_i};
        end
    end

    assign serial_o = sync_ff[STAGES-1];

endmodule