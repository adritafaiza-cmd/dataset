// =============================================================================
// Copyright (C) 2019-2020 Xilinx, Inc. All rights reserved.
// SPDX-License-Identifier: MIT
// =============================================================================

`timescale 1ns / 1ps

`include "axi_adapter_defines.vh"

`include "axi_adapter_pkg.vh"

module axis_adapter #(
    parameter S_DATA_WIDTH = 8,
    parameter S_KEEP_ENABLE = (S_DATA_WIDTH>8),
    parameter S_KEEP_WIDTH = ((S_DATA_WIDTH+7)/8),
    parameter M_DATA_WIDTH = 8,
    parameter M_KEEP_ENABLE = (M_DATA_WIDTH>8),
    parameter M_KEEP_WIDTH = ((M_DATA_WIDTH+7)/8),
    parameter ID_ENABLE = 0,
    parameter ID_WIDTH = 8,
    parameter DEST_ENABLE = 0,
    parameter DEST_WIDTH = 8,
    parameter USER_ENABLE = 1,
    parameter USER_WIDTH = 1
) (
    input  wire                     clk,
    input  wire                     rst,

    /*
     * AXI input
     */
    input  wire [S_DATA_WIDTH-1:0]  s_axis_tdata,
    input  wire [S_KEEP_WIDTH-1:0]  s_axis_tkeep,
    input  wire                     s_axis_tvalid,
    output wire                     s_axis_tready,
    input  wire                     s_axis_tlast,
    input  wire [ID_WIDTH-1:0]      s_axis_tid,
    input  wire [DEST_WIDTH-1:0]    s_axis_tdest,
    input  wire [USER_WIDTH-1:0]    s_axis_tuser,

    /*
     * AXI output
     */
    output wire [M_DATA_WIDTH-1:0]  m_axis_tdata,
    output wire [M_KEEP_WIDTH-1:0]  m_axis_tkeep,
    output wire                     m_axis_tvalid,
    input  wire                     m_axis_tready,
    output wire                     m_axis_tlast,
    output wire [ID_WIDTH-1:0]      m_axis_tid,
    output wire [DEST_WIDTH-1:0]    m_axis_tdest,
    output wire [USER_WIDTH-1:0]    m_axis_tuser
);

    localparam S_BYTES = (S_DATA_WIDTH+7)/8;
    localparam M_BYTES = (M_DATA_WIDTH+7)/8;

    localparam S_KEEP_WIDTH_ACTUAL = (S_KEEP_ENABLE ? S_KEEP_WIDTH : 1);
    localparam M_KEEP_WIDTH_ACTUAL = (M_KEEP_ENABLE ? M_KEEP_WIDTH : 1);

    localparam ID_WIDTH_ACTUAL = (ID_ENABLE ? ID_WIDTH : 1);
    localparam DEST_WIDTH_ACTUAL = (DEST_ENABLE ? DEST_WIDTH : 1);
    localparam USER_WIDTH_ACTUAL = (USER_ENABLE ? USER_WIDTH : 1);

    localparam S_BYTES_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES);
    localparam M_BYTES_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES);

    localparam S_BYTES_MASK = (1<<S_BYTES_LOG2)-1;
    localparam M_BYTES_MASK = (1<<M_BYTES_LOG2)-1;

    localparam S_BYTES_MINUS_1 = S_BYTES-1;
    localparam M_BYTES_MINUS_1 = M_BYTES-1;

    localparam S_BYTES_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES_MINUS_1);
    localparam M_BYTES_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES_MINUS_1);

    localparam S_BYTES_MINUS_1_MASK = (1<<S_BYTES_MINUS_1_LOG2)-1;
    localparam M_BYTES_MINUS_1_MASK = (1<<M_BYTES_MINUS_1_LOG2)-1;

    localparam S_BYTES_MINUS_1_MINUS_1 = S_BYTES_MINUS_1-1;
    localparam M_BYTES_MINUS_1_MINUS_1 = M_BYTES_MINUS_1-1;

    localparam S_BYTES_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES_MINUS_1_MINUS_1);
    localparam M_BYTES_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES_MINUS_1_MINUS_1);

    localparam S_BYTES_MINUS_1_MINUS_1_MASK = (1<<S_BYTES_MINUS_1_MINUS_1_LOG2)-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MASK = (1<<M_BYTES_MINUS_1_MINUS_1_LOG2)-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1 = S_BYTES_MINUS_1_MINUS_1-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1 = M_BYTES_MINUS_1_MINUS_1-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES_MINUS_1_MINUS_1_MINUS_1);
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES_MINUS_1_MINUS_1_MINUS_1);

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<S_BYTES_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<M_BYTES_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = S_BYTES_MINUS_1_MINUS_1_MINUS_1-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = M_BYTES_MINUS_1_MINUS_1_MINUS_1-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1);
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1);

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1);
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2 = `AXI_ADAPTER_CLOG2(M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1);

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MASK = (1<<M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2)-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1-1;
    localparam M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1 = M_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1-1;

    localparam S_BYTES_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_MINUS_1_LOG2