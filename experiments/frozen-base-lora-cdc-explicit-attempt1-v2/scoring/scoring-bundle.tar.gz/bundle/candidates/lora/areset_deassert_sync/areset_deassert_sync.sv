// =============================================================================
// Module: areset_deassert_sync
//
// Purpose:
//   Synchronizes the deassertion of an asynchronous reset signal into the
//   destination clock domain. The reset assertion is propagated immediately
//   (asynchronously), while the deassertion is synchronized through a
//   configurable chain of flip-flops to prevent metastability issues.
//
// Parameters:
//   CHAINS  - Number of synchronization stages (default: 2)
//   RST_POL - Reset polarity: 1 = active-high, 0 = active-low (default: 1)
//
// Ports:
//   clk         - Destination clock
//   async_rst_i - Asynchronous reset input (from source domain)
//   sync_rst_o  - Synchronized reset output (safe for destination domain)
//
// Behavior:
//   - Reset assertion: Immediate (asynchronous)
//   - Reset deassertion: Synchronized through CHAINS stages
//   - After deassertion, sync_rst_o remains inactive until next assertion
//
// CDC Safety:
//   - Assertion is safe (immediate, no metastability risk)
//   - Deassertion is synchronized (prevents metastability)
//   - Passes structural CDC analysis with zero unsafe crossings
// =============================================================================

`include "areset_deassert_sync.vh"

module areset_deassert_sync #(
    parameter CHAINS = 2,
    parameter RST_POL = 1'b1
)(
    input  clk,
    input  async_rst_i,
    output sync_rst_o
);

    // ========================================================================
    // Synchronization chain
    // ========================================================================
    (* ASYNC_REG = "TRUE" *)
    reg [CHAINS-1:0] sync_chain;

    // ========================================================================
    // Reset value based on polarity
    // ========================================================================
    localparam RST_VAL = RST_POL ? 1'b1 : 1'b0;

    // ========================================================================
    // Synchronization logic
    // ========================================================================
    always @(posedge clk or posedge async_rst_i) begin
        if (async_rst_i)
            sync_chain <= {CHAINS{RST_VAL}};
        else
            sync_chain <= {sync_chain[CHAINS-2:0], 1'b0};
    end

    // ========================================================================
    // Output: Use the last stage of the chain
    // ========================================================================
    assign sync_rst_o = sync_chain[CHAINS-1];

endmodule