// =============================================================================
// Copyright (C) 2019-2024  Avnet, Inc.
// =============================================================================
//
// This file is part of Avnet, Inc.
//
// SPDX-License-Identifier: MIT
//
// =============================================================================

`include "avnet_common.vh"

`include "avnet_fifo.vh"

`include "avnet_ram.vh"

module async_bidir_ramif_fifo
  #(
    parameter DSIZE         = 8,
    parameter ASIZE         = 4,
    parameter FALLTHROUGH   = "FALSE"
    ) (
       input wire              a_clk,
       input wire              a_rst_n,
       input wire              a_winc,
       input wire [DSIZE-1:0]  a_wdata,
       input wire              a_rinc,
       output wire [DSIZE-1:0] a_rdata,
       output wire             a_full,
       output wire             a_afull,
       output wire             a_empty,
       output wire             a_aempty,
       input wire              a_dir,

       input wire              b_clk,
       input wire              b_rst_n,
       input wire              b_winc,
       input wire [DSIZE-1:0]  b_wdata,
       input wire              b_rinc,
       output wire [DSIZE-1:0] b_rdata,
       output wire             b_full,
       output wire             b_afull,
       output wire             b_empty,
       output wire             b_aempty,
       input wire              b_dir,

       output wire             o_ram_a_clk,
       output wire [DSIZE-1:0] o_ram_a_wdata,
       input wire [DSIZE-1:0]  i_ram_a_rdata,
       output wire [ASIZE-1:0] o_ram_a_addr,
       output wire             o_ram_a_rinc,
       output wire             o_ram_a_winc,

       output wire             o_ram_b_clk,
       output wire [DSIZE-1:0] o_ram_b_wdata,
       input wire [DSIZE-1:0]  i_ram_b_rdata,
       output wire [ASIZE-1:0] o_ram_b_addr,
       output wire             o_ram_b_rinc,
       output wire             o_ram_b_winc
       );

  localparam RAM_DEPTH = 1 << ASIZE;

  localparam RAM_ASIZE = ASIZE;

  localparam RAM_DSIZE = DSIZE;

  localparam RAM_TYPE  = `AVNET_RAM_TYPE_SIMPLE_DUAL_PORT;

  localparam RAM_INIT  = "FALSE";

  localparam RAM_ACLK  = "FALSE";

  localparam RAM_BCLK  = "FALSE";

  localparam RAM_ARESET = "FALSE";

  localparam RAM_BRESET = "FALSE";

  localparam RAM_ARESET_POLARITY = "FALSE";

  localparam RAM_BRESET_POLARITY = "FALSE";

  localparam RAM_ARESET_SYNC = "FALSE";

  localparam RAM_BRESET_SYNC = "FALSE";

  localparam RAM_ARESET_SYNC_DEPTH = 2;

  localparam RAM_BRESET_SYNC_DEPTH = 2;

  localparam RAM_ARESET_SYNC_POLARITY = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_ARESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";

  localparam RAM_BRESET_SYNC_POLARITY_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT_INVERT = "FALSE";