// =============================================================================
// isochronous_4phase_handshake
// =============================================================================
// Four-phase valid/ready handshake between related (integer-ratio) clocks.
//
// Architecture:
//   - Source domain: 2-stage synchronizer for dst_ready_i.
//   - Destination domain: 2-stage synchronizer for src_valid_i.
//   - Four-phase protocol: valid/ready toggle on each transfer.
//   - No data payload.
// =============================================================================

`timescale 1ns / 1ps

module isochronous_4phase_handshake (
    input  src_clk_i,
    input  src_rst_ni,
    input  src_valid_i,
    output src_ready_o,

    input  dst_clk_i,
    input  dst_rst_ni,
    output dst_valid_o,
    input  dst_ready_i
);

    // =========================================================================
    // Source domain
    // =========================================================================

    // Synchronize dst_ready_i into source domain
    reg [1:0] dst_ready_sync;
    wire      dst_ready_src = dst_ready_sync[1];

    // Four-phase handshake state
    reg       src_valid_reg;
    reg       src_ready_reg;

    // src_ready_o is the registered ready signal
    assign src_ready_o = src_ready_reg;

    // Toggle src_valid_reg when src_valid_i and src_ready_reg are both high
    // Toggle src_ready_reg when dst_ready_src and src_valid_reg are both high
    always @(posedge src_clk_i or negedge src_rst_ni) begin
        if (!src_rst_ni) begin
            src_valid_reg <= 1'b0;
            src_ready_reg <= 1'b0;
        end else begin
            if (src_valid_i & src_ready_reg)
                src_valid_reg <= ~src_valid_reg;
            if (dst_ready_src & src_valid_reg)
                src_ready_reg <= ~src_ready_reg;
        end
    end

    // =========================================================================
    // Destination domain
    // =========================================================================

    // Synchronize src_valid_reg into destination domain
    reg [1:0] src_valid_sync;
    wire      src_valid_dst = src_valid_sync[1];

    // Four-phase handshake state
    reg       dst_valid_reg;
    reg       dst_ready_reg;

    // dst_valid_o is the registered valid signal
    assign dst_valid_o = dst_valid_reg;

    // Toggle dst_valid_reg when src_valid_dst and dst_ready_reg are both high
    // Toggle dst_ready_reg when dst_ready_i and dst_valid_reg are both high
    always @(posedge dst_clk_i or negedge dst_rst_ni) begin
        if (!dst_rst_ni) begin
            dst_valid_reg <= 1'b0;
            dst_ready_reg <= 1'b0;
        end else begin
            if (src_valid_dst & dst_ready_reg)
                dst_valid_reg <= ~dst_valid_reg;
            if (dst_ready_i & dst_valid_reg)
                dst_ready_reg <= ~dst_ready_reg;
        end
    end

    // =========================================================================
    // Synchronizers
    // =========================================================================

    // Synchronize dst_ready_i into source domain
    always @(posedge src_clk_i or negedge src_rst_ni) begin
        if (!src_rst_ni)
            dst_ready_sync <= 2'b00;
        else
            dst_ready_sync <= {dst_ready_sync[0], dst_ready_i};
    end

    // Synchronize src_valid_reg into destination domain
    always @(posedge dst_clk_i or negedge dst_rst_ni) begin
        if (!dst_rst_ni)
            src_valid_sync <= 2'b00;
        else
            src_valid_sync <= {src_valid_sync[0], src_valid_reg};
    end

endmodule