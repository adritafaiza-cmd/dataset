module sync_reset #
(
    parameter N = 2
)
(
    input  wire clk,
    input  wire rst,
    output wire out
);

    localparam DEPTH = (N < 2) ? 2 : N;

    reg [DEPTH-1:0] sync_reg;

    always @(posedge clk or posedge rst) begin
        if (rst)
            sync_reg <= {DEPTH{1'b1}};
        else
            sync_reg <= {sync_reg[DEPTH-2:0], 1'b0};
    end

    assign out = sync_reg[DEPTH-1];

endmodule
