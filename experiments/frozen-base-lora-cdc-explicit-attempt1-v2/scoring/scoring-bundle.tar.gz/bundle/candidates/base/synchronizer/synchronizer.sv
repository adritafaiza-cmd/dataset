module synchronizer #(
    parameter STAGES = 2
)(
    input  clk,
    input  rstn,
    input  async_sig_i,
    output sync_sig_o
);

    localparam MIN_STAGES = 2;
    localparam ACTUAL_STAGES = (STAGES < MIN_STAGES) ? MIN_STAGES : STAGES;

    reg [ACTUAL_STAGES-1:0] sync_reg;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            sync_reg <= {ACTUAL_STAGES{1'b0}};
        end else begin
            sync_reg[0] <= async_sig_i;
            for (integer i = 1; i < ACTUAL_STAGES; i = i + 1) begin
                sync_reg[i] <= sync_reg[i-1];
            end
        end
    end

    assign sync_sig_o = sync_reg[ACTUAL_STAGES-1];

endmodule
