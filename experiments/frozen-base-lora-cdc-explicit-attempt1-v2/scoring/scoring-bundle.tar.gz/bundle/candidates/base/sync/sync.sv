module sync #(
    parameter int unsigned STAGES = 2,
    parameter bit ResetValue = 1'b0
) (
    input  logic clk_i,
    input  logic rst_ni,
    input  logic serial_i,
    output logic serial_o
);

    localparam int unsigned MIN_STAGES = 2;
    localparam int unsigned ACTUAL_STAGES = (STAGES < MIN_STAGES) ? MIN_STAGES : STAGES;

    logic [ACTUAL_STAGES-1:0] sync_reg;

    always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
            sync_reg <= {ACTUAL_STAGES{ResetValue}};
        end else begin
            sync_reg[0] <= serial_i;
            for (int unsigned i = 1; i < ACTUAL_STAGES; i++) begin
                sync_reg[i] <= sync_reg[i-1];
            end
        end
    end

    assign serial_o = sync_reg[ACTUAL_STAGES-1];

endmodule
