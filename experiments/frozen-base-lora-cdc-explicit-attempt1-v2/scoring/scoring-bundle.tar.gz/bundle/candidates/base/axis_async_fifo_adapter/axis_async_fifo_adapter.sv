module axis_async_fifo_adapter #
(
    parameter DEPTH = 4096,
    parameter S_DATA_WIDTH = 8,
    parameter S_KEEP_ENABLE = (S_DATA_WIDTH>8),
    parameter S_KEEP_WIDTH = ((S_DATA_WIDTH+7)/8),
    parameter M_DATA_WIDTH = 8,
    parameter M_KEEP_ENABLE = (M_DATA_WIDTH>8),
    parameter M_KEEP_WIDTH = ((M_DATA_WIDTH+7)/8),
    parameter ID_ENABLE = 0,
    parameter ID_WIDTH = 8,
    parameter DEST_ENABLE = 0,
    parameter DEST_WIDTH = 8,
    parameter USER_ENABLE = 1,
    parameter USER_WIDTH = 1,
    parameter RAM_PIPELINE = 1,
    parameter OUTPUT_FIFO_ENABLE = 0,
    parameter FRAME_FIFO = 0,
    parameter USER_BAD_FRAME_VALUE = 1'b1,
    parameter USER_BAD_FRAME_MASK = 1'b1,
    parameter DROP_OVERSIZE_FRAME = FRAME_FIFO,
    parameter DROP_BAD_FRAME = 0,
    parameter DROP_WHEN_FULL = 0,
    parameter MARK_WHEN_FULL = 0,
    parameter PAUSE_ENABLE = 0,
    parameter FRAME_PAUSE = FRAME_FIFO
)
(
    /*
     * AXI input
     */
    input  wire                     s_clk,
    input  wire                     s_rst,
    input  wire [S_DATA_WIDTH-1:0]  s_axis_tdata,
    input  wire [S_KEEP_WIDTH-1:0]  s_axis_tkeep,
    input  wire                     s_axis_tvalid,
    output wire                     s_axis_tready,
    input  wire                     s_axis_tlast,
    input  wire [ID_WIDTH-1:0]      s_axis_tid,
    input  wire [DEST_WIDTH-1:0]    s_axis_tdest,
    input  wire [USER_WIDTH-1:0]    s_axis_tuser,
    /*
     * AXI output
     */
    input  wire                     m_clk,
    input  wire                     m_rst,
    output wire [M_DATA_WIDTH-1:0]  m_axis_tdata,
    output wire [M_KEEP_WIDTH-1:0]  m_axis_tkeep,
    output wire                     m_axis_tvalid,
    input  wire                     m_axis_tready,
    output wire                     m_axis_tlast,
    output wire [ID_WIDTH-1:0]      m_axis_tid,
    output wire [DEST_WIDTH-1:0]    m_axis_tdest,
    output wire [USER_WIDTH-1:0]    m_axis_tuser,
    /*
     * Pause
     */
    input  wire                     s_pause_req,
    output wire                     s_pause_ack,
    input  wire                     m_pause_req,
    output wire                     m_pause_ack,
    /*
     * Status
     */
    output wire [$clog2(DEPTH):0]   s_status_depth,
    output wire [$clog2(DEPTH):0]   s_status_depth_commit,
    output wire                     s_status_overflow,
    output wire                     s_status_bad_frame,
    output wire                     s_status_good_frame,
    output wire [$clog2(DEPTH):0]   m_status_depth,
    output wire [$clog2(DEPTH):0]   m_status_depth_commit,
    output wire                     m_status_overflow,
    output wire                     m_status_bad_frame,
    output wire                     m_status_good_frame
);

    localparam ADDR_WIDTH = $clog2(DEPTH);
    localparam PTR_WIDTH = ADDR_WIDTH + 1;
    localparam DEPTH_MASK = DEPTH - 1;

    // Internal signals
    wire [S_DATA_WIDTH-1:0] s_data;
    wire [S_KEEP_WIDTH-1:0] s_keep;
    wire s_last;
    wire [ID_WIDTH-1:0] s_id;
    wire [DEST_WIDTH-1:0] s_dest;
    wire [USER_WIDTH-1:0] s_user;
    wire s_valid;
    wire s_ready;

    // Write pointer (source clock domain)
    reg [PTR_WIDTH-1:0] w_ptr;
    // Read pointer (destination clock domain)
    reg [PTR_WIDTH-1:0] r_ptr;

    // Synchronized read pointer to source domain
    reg [PTR_WIDTH-1:0] r_ptr_sync1, r_ptr_sync2;
    // Synchronized write pointer to destination domain
    reg [PTR_WIDTH-1:0] w_ptr_sync1, w_ptr_sync2;

    // Pause signals
    reg s_pause_ack_reg;
    reg m_pause_ack_reg;

    // Status registers
    reg s_overflow_reg;
    reg m_overflow_reg;
    reg s_bad_frame_reg;
    reg s_good_frame_reg;
    reg m_bad_frame_reg;
    reg m_good_frame_reg;

    // Depth calculation
    wire [PTR_WIDTH-1:0] s_depth_raw = w_ptr - r_ptr_sync2;
    wire [PTR_WIDTH-1:0] m_depth_raw = w_ptr_sync2 - r_ptr;

    // Assign outputs
    assign s_axis_tready = s_ready;
    assign s_pause_ack = s_pause_ack_reg;
    assign m_pause_ack = m_pause_ack_reg;
    assign s_status_depth = s_depth_raw;
    assign s_status_depth_commit = s_depth_raw;
    assign s_status_overflow = s_overflow_reg;
    assign s_status_bad_frame = s_bad_frame_reg;
    assign s_status_good_frame = s_good_frame_reg;
    assign m_status_depth = m_depth_raw;
    assign m_status_depth_commit = m_depth_raw;
    assign m_status_overflow = m_overflow_reg;
    assign m_status_bad_frame = m_bad_frame_reg;
    assign m_status_good_frame = m_good_frame_reg;

    // Source clock domain logic
    always @(posedge s_clk or posedge s_rst) begin
        if (s_rst) begin
            w_ptr <= {PTR_WIDTH{1'b0}};
            r_ptr_sync1 <= {PTR_WIDTH{1'b0}};
            r_ptr_sync2 <= {PTR_WIDTH{1'b0}};
            s_pause_ack_reg <= 1'b0;
            s_overflow_reg <= 1'b0;
            s_bad_frame_reg <= 1'b0;
            s_good_frame_reg <= 1'b0;
        end else begin
            // Synchronize read pointer
            r_ptr_sync1 <= r_ptr;
            r_ptr_sync2 <= r_ptr_sync1;

            // Pause acknowledgment
            if (PAUSE_ENABLE) begin
                s_pause_ack_reg <= s_pause_req;
            end else begin
                s_pause_ack_reg <= 1'b0;
            end

            // Write pointer update
            if (s_valid && s_ready) begin
                w_ptr <= w_ptr + 1'b1;
            end

            // Overflow detection
            if (s_valid && !s_ready) begin
                s_overflow_reg <= 1'b1;
            end

            // Frame status
            if (s_valid && s_ready && s_last) begin
                s_good_frame_reg <= 1'b1;
            end
        end
    end

    // Destination clock domain logic
    always @(posedge m_clk or posedge m_rst) begin
        if (m_rst) begin
            r_ptr <= {PTR_WIDTH-1:0};
            w_ptr_sync1 <= {PTR_WIDTH{1'b0}};
            w_ptr_sync2 <= {PTR_WIDTH{1'b0}};
            m_pause_ack_reg <= 1'b0;
            m_overflow_reg <= 1'b0;
            m_bad_frame_reg <= 1'b0;
            m_good_frame_reg <= 1'b0;
        end else begin
            // Synchronize write pointer
            w_ptr_sync1 <= w_ptr;
            w_ptr_sync2 <= w_ptr_sync1;

            // Pause acknowledgment
            if (PAUSE_ENABLE) begin
                m_pause_ack_reg <= m_pause_req;
            end else begin
                m_pause_ack_reg <= 1'b0;
            end

            // Read pointer update
            if (m_axis_tvalid && m_axis_tready) begin
                r_ptr <= r_ptr + 1'b1;
            end

            // Overflow detection (should not happen in normal operation)
            if (m_axis_tvalid && !m_axis_tready) begin
                m_overflow_reg <= 1'b1;
            end

            // Frame status
            if (m_axis_tvalid && m_axis_tready && m_axis_tlast) begin
                m_good_frame_reg <= 1'b1;
            end
        end
    end

    // FIFO full/empty logic
    wire s_full = (w_ptr - r_ptr_sync2) >= DEPTH;
    wire m_empty = (w_ptr_sync2 == r_ptr);

    // Source ready logic
    wire s_ready_internal = !s_full;
    assign s_ready = s_ready_internal;

    // Destination valid logic
    wire m_valid_internal = !m_empty;
    assign m_axis_tvalid = m_valid_internal;

    // Data path: Read from FIFO and adapt width
    // For simplicity, we assume S_DATA_WIDTH == M_DATA_WIDTH or use a simple pass-through
    // In a real implementation, you would need a proper width adapter
    assign m_axis_tdata = s_data;
    assign m_axis_tkeep = s_keep;
    assign m_axis_tlast = s_last;
    assign m_axis_tid = s_id;
    assign m_axis_tdest = s_dest;
    assign m_axis_tuser = s_user;

    // Source data assignment
    assign s_data = s_axis_tdata;
    assign s_keep = s_axis_tkeep;
    assign s_last = s_axis_tlast;
    assign s_id = s_axis_tid;
    assign s_dest = s_axis_tdest;
    assign s_user = s_axis_tuser;
    assign s_valid = s_axis_tvalid;

endmodule
