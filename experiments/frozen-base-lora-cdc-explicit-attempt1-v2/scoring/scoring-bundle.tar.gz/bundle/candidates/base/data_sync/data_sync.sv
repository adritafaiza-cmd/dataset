module data_sync #(
    parameter STAGES = 2,
    parameter DWIDTH = 8
)(
    input                  clk,
    input                  rstn,
    input  [DWIDTH-1:0]    din,
    input                  dready_i,
    output reg [DWIDTH-1:0] dout,
    output reg             dready_o
);

    // Use a minimum of 2 stages for safe CDC
    localparam SYNC_STAGES = (STAGES < 2) ? 2 : STAGES;

    // Synchronizer chain for the handshake signal
    reg [SYNC_STAGES-1:0] sync_chain;

    // Latch the data when the handshake is detected
    reg [DWIDTH-1:0] data_latch;
    reg              data_valid;

    // Synchronize the handshake signal
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            sync_chain <= {SYNC_STAGES{1'b0}};
        end else begin
            sync_chain[0] <= dready_i;
            for (integer i = 1; i < SYNC_STAGES; i = i + 1) begin
                sync_chain[i] <= sync_chain[i-1];
            end
        end
    end

    // Detect rising edge of the synchronized handshake
    wire sync_rise = sync_chain[SYNC_STAGES-1] & ~sync_chain[SYNC_STAGES-2];

    // Latch data and generate output pulse
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            data_latch <= {DWIDTH{1'b0}};
            data_valid <= 1'b0;
            dout       <= {DWIDTH{1'b0}};
            dready_o   <= 1'b0;
        end else begin
            if (sync_rise) begin
                data_latch <= din;
                data_valid <= 1'b1;
            end else begin
                data_valid <= 1'b0;
            end

            if (data_valid) begin
                dout     <= data_latch;
                dready_o <= 1'b1;
            end else begin
                dready_o <= 1'b0;
            end
        end
    end

endmodule
